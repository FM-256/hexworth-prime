const puppeteer = require('puppeteer');
const CLOUD_MASTER = {"id":"cloud-master","category":"platform-hub","label":"Cloud Master","sublabel":"Cloud Hub Collection","icon":"/assets/images/icons/icon-cloud.webp","houseId":"observatory","hubHref":"/houses/hub/cloud-master","tenantAssignable":true,"sortOrder":200,"status":"published"};
const CONSENT_STUB = 'window.ObservatoryConsent={ensureConsent:function(cb){cb();},showChangeClass:function(){},showBanner:function(){}};';
const FIREBASE_STUB = `
window.ArenaFirebase = { db: {__stub:true}, init: function(){ return Promise.resolve(); } };
window.firebaseFirestore = {
  collection: function(db, name){ return {__col:name}; },
  query: function(col){ return col; },
  where: function(){ return {}; },
  getDocs: function(q){ return Promise.resolve({ forEach: function(fn){ fn({ id: 'cloud-master', data: function(){ return ${JSON.stringify(CLOUD_MASTER)}; } }); } }); }
};`;
(async () => {
  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'] });
  const page = await browser.newPage();
  const pageErrors = [];
  page.on('pageerror', e => pageErrors.push(String(e).slice(0, 140)));
  await page.setRequestInterception(true);
  page.on('request', req => {
    const u = req.url();
    if (u.includes('/components/ObservatoryConsent.js')) return req.respond({ contentType: 'application/javascript', body: CONSENT_STUB });
    if (u.includes('/arena/firebase-init.js')) return req.respond({ contentType: 'application/javascript', body: FIREBASE_STUB });
    if (u.includes('firebaseapp.com') || u.includes('googleapis.com') || u.includes('gstatic.com')) return req.abort();
    req.continue();
  });
  await page.evaluateOnNewDocument(() => { localStorage.setItem('hexworth_house', 'observatory'); });
  await page.setViewport({ width: 1920, height: 1080 });
  let fails = 0;

  await page.goto('http://localhost:8143/houses/observatory/index.html', { waitUntil: 'networkidle2', timeout: 60000 });
  await new Promise(r => setTimeout(r, 4000));
  const obs = await page.evaluate(() => {
    const grid = document.querySelector('#hr-panel-paths .hr-cart-grid');
    const cards = grid ? [...grid.children] : [];
    const cmIdx = cards.findIndex(c => /cloud master/i.test(c.textContent));
    const neighbors = cmIdx >= 0 ? [cards[cmIdx-1], cards[cmIdx+1]].map(c => c ? c.textContent.trim().slice(0, 30) : null) : null;
    const cmAnywhere = [...document.querySelectorAll('a')].filter(a => /cloud master/i.test(a.textContent));
    const cmHref = cmAnywhere[0] ? cmAnywhere[0].getAttribute('href') || cmAnywhere[0].closest('a')?.href : null;
    const aboveMain = document.querySelector('body > a[href*="cloud-master"], body > div a[href*="cloud-master"]');
    const panels = [...document.querySelectorAll('[id^=hr-panel-]')].map(p => ({ id: p.id, cm: [...p.querySelectorAll('a')].filter(a => /cloud master/i.test(a.textContent)).length }));
    return { gridCards: cards.length, cmIdx, neighbors, cmCount: cmAnywhere.length, cmHref, panels };
  });
  console.log('observatory:', JSON.stringify(obs));
  const once = obs.cmCount === 1 && obs.cmIdx >= 0 && obs.panels.filter(p => p.cm > 0).length === 1;
  if (!once) fails++;

  await page.evaluateOnNewDocument(() => { localStorage.setItem('hexworth_house', 'cloud'); });
  await page.goto('http://localhost:8143/houses/cloud/index.html', { waitUntil: 'networkidle2', timeout: 60000 });
  await new Promise(r => setTimeout(r, 3000));
  const cl = await page.evaluate(() => ({
    cards: document.querySelectorAll('.hr-cart-grid > *').length,
    cm: [...document.querySelectorAll('a')].filter(a => /cloud master/i.test(a.textContent)).length
  }));
  console.log('cloud house:', JSON.stringify(cl), '(cm MUST be 0 — houseId=observatory)');
  if (!(cl.cards > 0 && cl.cm === 0)) fails++;

  console.log('pageErrors:', pageErrors.length, pageErrors.slice(0, 3));
  if (pageErrors.length) fails++;
  console.log(fails === 0 ? 'STUB VERIFY: PASS' : `STUB VERIFY: ${fails} FAIL(S)`);
  await browser.close();
  process.exit(fails ? 1 : 0);
})().catch(e => { console.error('HARNESS ERROR:', e.message); process.exit(2); });
