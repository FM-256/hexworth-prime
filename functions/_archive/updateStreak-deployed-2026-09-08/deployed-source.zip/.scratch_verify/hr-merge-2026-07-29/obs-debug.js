const puppeteer = require('puppeteer');
(async () => {
  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'] });
  const page = await browser.newPage();
  const console_ = [];
  page.on('console', m => console_.push(m.type() + ': ' + m.text().slice(0, 120)));
  await page.evaluateOnNewDocument(() => { localStorage.setItem('hexworth_house', 'observatory'); });
  await page.goto('https://hexworth-prime--hr-dynamic-merge-pj4v2s7g.web.app/houses/observatory/index.html', { waitUntil: 'networkidle2', timeout: 60000 });
  await new Promise(r => setTimeout(r, 5000));
  const d = await page.evaluate(() => ({
    hrPanels: [...document.querySelectorAll('[id*=panel]')].map(e => e.id).slice(0, 8),
    cartGrids: document.querySelectorAll('.hr-cart-grid').length,
    anyGridClasses: [...new Set([...document.querySelectorAll('[class*=grid]')].map(e => e.className.split(' ').find(c => c.includes('grid'))))].slice(0, 8),
    coursesHeadings: [...document.querySelectorAll('h1,h2,h3')].map(h => h.textContent.trim()).slice(0, 10),
    hasInit: typeof HouseRenderer !== 'undefined'
  }));
  console.log(JSON.stringify(d, null, 1));
  console.log('console tail:', console_.slice(-6));
  await browser.close();
})().catch(e => { console.error('ERR:', e.message); process.exit(2); });
