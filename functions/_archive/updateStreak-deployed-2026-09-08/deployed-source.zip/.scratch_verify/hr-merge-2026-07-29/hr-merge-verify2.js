const puppeteer = require('puppeteer');
const BASE = 'https://hexworth-prime--hr-dynamic-merge-pj4v2s7g.web.app';
(async () => {
  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'] });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e).slice(0, 140)));
  await page.evaluateOnNewDocument(() => { localStorage.setItem('hexworth_house', 'observatory'); });
  await page.setViewport({ width: 1920, height: 1080 });
  let fails = 0;

  await page.goto(`${BASE}/houses/observatory/index.html`, { waitUntil: 'networkidle2', timeout: 60000 });
  await new Promise(r => setTimeout(r, 5000));
  const obs = await page.evaluate(() => {
    const mounts = document.querySelectorAll('[data-hub-discovery]').length;
    const grid = document.querySelector('#hr-panel-paths .hr-cart-grid');
    const gridCards = grid ? [...grid.children] : [];
    const cmInGrid = gridCards.filter(c => /cloud master/i.test(c.textContent));
    const cmAnywhere = [...document.querySelectorAll('a')].filter(a => /cloud master/i.test(a.textContent));
    const cmIdx = gridCards.findIndex(c => /cloud master/i.test(c.textContent));
    const firstEl = document.body.firstElementChild;
    const topIsHubCard = firstEl ? /cloud master|hub/i.test((firstEl.textContent || '').slice(0, 80)) : false;
    // per-tab uniqueness: count cloud-master links per panel
    const panels = [...document.querySelectorAll('[id^=hr-panel-]')].map(p => ({
      id: p.id, cm: [...p.querySelectorAll('a')].filter(a => /cloud master/i.test(a.textContent)).length
    }));
    return { mounts, gridCount: gridCards.length, cmInGrid: cmInGrid.length, cmAnywhere: cmAnywhere.length, cmIdx, topIsHubCard, panels };
  });
  console.log('observatory:', JSON.stringify(obs));
  if (!(obs.mounts === 0 && obs.cmInGrid === 1 && obs.cmAnywhere === 1 && !obs.topIsHubCard)) fails++;

  for (const h of ['cloud', 'shield']) {
    await page.goto(`${BASE}/houses/${h}/index.html`, { waitUntil: 'networkidle2', timeout: 60000 });
    await new Promise(r => setTimeout(r, 3000));
    const r = await page.evaluate(() => ({
      grids: document.querySelectorAll('.hr-cart-grid').length,
      cards: document.querySelectorAll('.hr-cart-grid > *').length,
      mounts: document.querySelectorAll('[data-hub-discovery]').length
    }));
    console.log(`${h}:`, JSON.stringify(r));
    if (!(r.cards > 0 && r.mounts === 0)) fails++;
  }

  // security-plus page (no HouseRenderer): loads clean without the removed script
  await page.goto(`${BASE}/houses/shield/security-plus/index.html`, { waitUntil: 'networkidle2', timeout: 60000 });
  await new Promise(r => setTimeout(r, 2000));
  const sp = await page.evaluate(() => ({ title: document.title.slice(0, 40), bodyLen: document.body.innerText.length, mounts: document.querySelectorAll('[data-hub-discovery]').length }));
  console.log('security-plus:', JSON.stringify(sp));
  if (!(sp.bodyLen > 200 && sp.mounts === 0)) fails++;

  console.log('pageErrors:', errors.length, errors.slice(0, 3));
  if (errors.length) fails++;
  console.log(fails === 0 ? 'HR-MERGE COMPLETE-FIX VERIFY: PASS' : `HR-MERGE COMPLETE-FIX VERIFY: ${fails} FAIL(S)`);
  await browser.close();
  process.exit(fails ? 1 : 0);
})().catch(e => { console.error('HARNESS ERROR:', e.message); process.exit(2); });
