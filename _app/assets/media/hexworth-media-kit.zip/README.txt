HEXWORTH PRIME, BRAND & MEDIA KIT
=================================
Cyan (#22D3EE) is the canonical brand color.

/logos
  mark-cyan-{1024,512,256,128}.png   Primary mark. Use on DARK backgrounds only.
                                     (Cyan on white is low-contrast; use mark-black on light.)
  mark-white-{1024,512,256}.png      White knockout. For dark or photographic backgrounds.
  mark-black-{1024,512,256}.png      Black mark. For LIGHT or print backgrounds.
  emblem-cyan-full.png               Full neon wordmark emblem. DARK backgrounds only.
  monogram-cyan-{512,256}.png        "HP" hexagon monogram. Compact spaces / favicons.

/social
  social-avatar-{512,400}.png        Profile picture.
  social-banner.png    1500x500      Cover / header banner.
  social-badge.png                   "Powered by Hexworth Prime" badge for partners & bloggers.
  hero-1600.jpg                      Hero illustration (the twelve-house menagerie).

hexworth-media-kit.pdf               Full company overview deck.

USAGE
  Do:    cyan or white mark on dark; black mark on light; keep clear space of at least the
         hexagon's height around the mark.
  Don't: recolor the mark outside the brand cyan; stretch or rotate it; place the neon
         emblem on a light background.

  More assets, colors, and guidance: https://hexworth.com/brand
  Custom formats or lockups: frank@hexworth.com
